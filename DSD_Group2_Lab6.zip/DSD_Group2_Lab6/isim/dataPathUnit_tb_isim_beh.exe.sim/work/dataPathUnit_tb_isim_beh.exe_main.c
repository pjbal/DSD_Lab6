/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_1242562249;
char *IEEE_P_3620187407;
char *STD_STANDARD;
char *IEEE_P_3499444699;
char *IEEE_P_2592010699;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    work_a_1188427897_3212880686_init();
    work_a_0146488010_3212880686_init();
    work_a_0153626076_0578964516_init();
    work_a_3668199810_3212880686_init();
    work_a_0091457252_3212880686_init();
    work_a_1657707143_3212880686_init();
    work_a_0442931979_3212880686_init();
    work_a_1842573716_3212880686_init();
    ieee_p_1242562249_init();
    work_a_0243557410_3212880686_init();
    work_a_0067706483_3212880686_init();
    work_a_4179008108_3212880686_init();
    work_a_3595315719_3212880686_init();
    work_a_0673676855_3212880686_init();
    work_a_0972446628_3212880686_init();
    work_a_3166451387_3212880686_init();
    work_a_1398904509_3212880686_init();
    work_a_0337651836_3212880686_init();
    work_a_2879229397_3212880686_init();
    work_a_3649328173_3212880686_init();
    work_a_3006959317_3212880686_init();
    work_a_2951549607_3212880686_init();
    work_a_2973221874_3212880686_init();
    work_a_4012079745_3212880686_init();
    work_a_1620803328_3212880686_init();
    work_a_0923713457_3212880686_init();
    work_a_0413558560_3212880686_init();
    work_a_2614767529_3212880686_init();
    work_a_4261028879_2414388652_init();
    work_a_0733220419_0777901596_init();
    work_a_2715128386_3212880686_init();
    work_a_2474565320_3212880686_init();
    work_a_2823642464_3212880686_init();
    work_a_2483091423_3212880686_init();
    work_a_2484018793_3212880686_init();
    work_a_0626976751_3212880686_init();
    work_a_1137731566_3212880686_init();
    work_a_3331395414_3212880686_init();
    work_a_0175984210_3212880686_init();
    work_a_1497024775_2372691052_init();


    xsi_register_tops("work_a_1497024775_2372691052");

    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);

    return xsi_run_simulation(argc, argv);

}
